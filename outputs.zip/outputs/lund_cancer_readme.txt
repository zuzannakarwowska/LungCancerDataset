procrustes - folder with Procrustes results. 

- A1.csv, A2.csv - For each dataset (e.g., A1.csv, A2.csv), I calculated beta diversity between samples using both relative and absolute data. I then applied Procrustes analysis to create an ordination that compares the distance matrices derived from these two types of data.

M1 is the distance matrix based on relative data, adjusted by Procrustes analysis to align with the distance matrix from the absolute data.
M2 is the distance matrix based on relative data, adjusted by Procrustes analysis to align with another distance matrix based on relative data.
For each distance metric, such as Bray-Curtis:

Please note that these matrices (M1, M2, BC1, BC2) are not the original beta diversity matrices between samples; they are distance matrices modified by Procrustes analysis.

- procrustes.png is the plot I did based on those M1 and M2 matrices
- disparity.csv is the csv with disparity measures for given beta diversity


DA - folder with differential abundance data

- LMMs_results - results for linear mixed models where formula = bacteria ~ Progression + 1|Patient. P-values are not adjusted for multiple comparisons. If a p-value is not reported, it is considered to be 1. This often occurs when there is insufficient abundance to calculate differential abundance (DA) for a specific bacterium. The distance refers to the Euclidean distance between the p-values for a bacterium from the LMM analysis on absolute data versus relative data. This distance quantifies how different the results are for the same model and bacterium when applied to relative data compared to absolute data.

- Wilcoxon_results - same as for LMMs but Wilcoxon test


alpha_diversity 

- alpha_diversities_Mann_test.csv - UMann test for alpha diversity for the same sample but for relative and absolute data

- alpha_diversities.csv - Calculated alpha diversities

- shannon.png - example boxplot we were talking about
